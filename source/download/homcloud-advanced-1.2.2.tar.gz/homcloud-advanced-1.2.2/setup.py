# You should run this script in the same directory of this file.

import os
import re
from setuptools import setup

version_info = open('homcloud/advanced.py', 'r').readlines()
for line in version_info:
    if line.find("version") >= 0:
        version_number = str(re.sub('[^0-9|\.]', '', line))

# The following branch is requied since pytest-runner is not
# packaged on debian jessie.
# This will be removed when debian stretch is released.
if os.environ.get("HOMCLOUD_DISABLE_PYTEST_RUNNER", "0") == "1":
    SETUP_REQUIRES = []
else:
    SETUP_REQUIRES = ["pytest-runner"]

setup(
    name="homcloud-advanced",
    version=version_number,
    description="homcloud advanced tools",
    author="Ippei Obayashi",
    author_email="ippei.obayashi.d8@tohoku.ac.jp",
    url="http://www.wpi-aimr.tohoku.ac.jp/hiraoka_labo/homcloud",
    packages=[
        "homcloud",
        "homcloud.histopixels",
        "homcloud.pict",
    ],
    entry_points={
        'console_scripts': [
            "homcloud-dump-diagram = homcloud.dump_diagram:main",
            "homcloud-plot-PD = homcloud.plot_PD:main",
            "homcloud-plot-PD-gui = homcloud.plot_PD_gui:main",
            "homcloud-proj-histo = homcloud.proj_histo:main",
            "homcloud-pwgk = homcloud.pwgk:main",
            "homcloud-vectorize-PD = homcloud.vectorize_PD:main",
            "homcloud-view-birth-death-simplices = homcloud.view_birth_death:main",
            "homcloud-view-index-pict = homcloud.view_index_pict:main",
            "homcloud-view-index-pict-gui = homcloud.view_index_pict_gui:main",
            "homcloud-view-vectorized-PD = homcloud.view_vectorized_PD:main",
            "homcloud-full-ph-tree = homcloud.full_ph_tree:main",
            "homcloud-query-full-ph-tree = homcloud.query_full_ph_tree:main",
            "homcloud-optimal-cycle = homcloud.optimal_cycle:main",
            "homcloud-plot-PD-slice = homcloud.plot_PD_slice:main",
            "homcloud-pict-show-volume-2d = homcloud.pict.show_volume_2d:main",
            "homcloud-query-pht = homcloud.query_pht:main",
        ],
    },
    install_requires=[
        "numpy",
        "matplotlib",
        "scipy",
        "scikit-learn",
        "msgpack-python",
        "Pillow",
        "pulp",
    ],
    setup_requires=SETUP_REQUIRES,
    tests_require=[
        "pytest>=3.0",
        "pytest-mock",
    ],
)
