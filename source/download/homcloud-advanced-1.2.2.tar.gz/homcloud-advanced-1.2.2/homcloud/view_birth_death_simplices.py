import argparse
import sys
import operator
import itertools

import numpy as np
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavigationToolbar
)
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
from PyQt5.QtWidgets import QMainWindow, QApplication, QErrorMessage
from PyQt5.QtCore import QCoreApplication, QAbstractListModel, QVariant
import PyQt5.QtCore as QtCore

import homcloud.view_birth_death_simplices_ui as ui
import homcloud.utils as utils

def main():
    app = QApplication(sys.argv)
    args = argument_parser().parse_args(app.arguments()[1:])
    pointcloud = np.loadtxt(args.pointcloud)
    diagram = utils.load_diagrams(args.type, args.input, args.degree, args.negate)
    app.lastWindowClosed.connect(MainWindow.quit)
    main_window = MainWindow(diagram, pointcloud)
    main_window.show()
    sys.exit(app.exec_())

def argument_parser():
    p = argparse.ArgumentParser(description="View birth/death simplices interactively")
    utils.add_arguments_for_load_diagrams(p)
    p.add_argument("pointcloud", help="point cloud data")
    p.add_argument("input", nargs="*", help="input file name")
    return p

class MainWindow(QMainWindow):
    def __init__(self, diagram, pointcloud, parent=None):
        super(MainWindow, self).__init__(parent)
        self.diagram = diagram
        self.pointcloud = pointcloud

        self.ui = ui.Ui_MainWindow()
        self.ui.setupUi(self)
        self.setup_mpl_canvas()

        self.pairs_model = PairsModel(diagram, self)

        self.ui.actionQuit.triggered.connect(self.quit)
        self.ui.button_apply_filter.clicked.connect(self.on_apply_filters)
        self.ui.listview_pairs.setModel(self.pairs_model)
        self.ui.listview_pairs.clicked.connect(self.on_click_pair)

    @staticmethod
    def quit():
        QCoreApplication.instance().quit()

    def setup_mpl_canvas(self):
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        self.ui.layout_mpl.addWidget(self.canvas)
        self.canvas.draw()
        toolbar = NavigationToolbar(self.canvas, self, coordinates=True)
        self.addToolBar(toolbar)

    def on_apply_filters(self):
        try:
            self.pairs_model.beginResetModel()
            self.apply_filters()
        except ValueError:
            QErrorMessage(self).showMessage("Invalid filter parameter")
        finally:
            self.pairs_model.endResetModel()

    def apply_filters(self):
        self.pairs_model.reset_filter()
        self.pairs_model.apply_filter(self.ui.edit_min_birth.text(),
                                      lambda pair, th: pair.birth >= th)
        self.pairs_model.apply_filter(self.ui.edit_max_birth.text(),
                                      lambda pair, th: pair.birth <= th)
        self.pairs_model.apply_filter(self.ui.edit_min_death.text(),
                                      lambda pair, th: pair.death >= th)
        self.pairs_model.apply_filter(self.ui.edit_max_death.text(),
                                      lambda pair, th: pair.death <= th)
        self.pairs_model.apply_filter(self.ui.edit_min_lifetime.text(),
                                      lambda pair, th: pair.lifetime() >= th)
        self.pairs_model.apply_filter(self.ui.edit_max_lifetime.text(),
                                      lambda pair, th: pair.lifetime() <= th)

    def on_click_pair(self, index):
        selected_pair = self.pairs_model.filtered_pairs[index.row()]
        birth_simplex = selected_pair.birth_pos
        death_simplex = selected_pair.death_pos
        all_points = np.array(birth_simplex + death_simplex)
        # (xs, ys, zs) = all_points.T
        # x_range = self.find_range(xs)
        # y_range = self.find_range(ys)
        # z_range = self.find_range(zs)
        (x_range, y_range, z_range) = self.xyz_ranges(all_points)
        x_mask = (self.pointcloud[:, 0] > x_range[0]) & (self.pointcloud[:, 0] < x_range[1])
        y_mask = (self.pointcloud[:, 1] > y_range[0]) & (self.pointcloud[:, 1] < y_range[1])
        z_mask = (self.pointcloud[:, 2] > z_range[0]) & (self.pointcloud[:, 2] < z_range[1])
        mask = x_mask & y_mask & z_mask
        points_in_neighbour = self.pointcloud[mask, :]
        self.show_pointcloud(points_in_neighbour, birth_simplex, death_simplex, x_range, y_range, z_range)

    @staticmethod
    def find_range(values):
        maximum = values.max()
        minimum = values.min()
        diff = maximum - minimum
        return (minimum - diff, maximum + diff)

    @staticmethod
    def xyz_ranges(points):
        (xs, ys, zs) = points.T
        x_size = xs.max() - xs.min()
        y_size = ys.max() - ys.min()
        z_size = zs.max() - zs.min()
        size = max([x_size, y_size, z_size])
        x_center = xs.min() + x_size/2
        y_center = ys.min() + y_size/2
        z_center = zs.min() + z_size/2
        return ((x_center - 1.5*size, x_center + 1.5*size),
                (y_center - 1.5*size, y_center + 1.5*size),
                (z_center - 1.5*size, z_center + 1.5*size))

    def show_pointcloud(self, points, birth_simplex, death_simplex, x_range, y_range, z_range):
        self.figure.clf()
        ax = self.figure.add_subplot(111, projection='3d')
        ax.set_xlim(*x_range)
        ax.set_ylim(*y_range)
        ax.set_zlim(*z_range)
        self.draw_simplex(ax, birth_simplex, "blue")
        self.draw_simplex(ax, death_simplex, "red")
        colors = points[:,3] if points.shape[1] == 4 else "b"
        collection = ax.scatter(points[:, 0], points[:, 1], points[:, 2], c=colors, cmap=matplotlib.cm.rainbow)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")
        self.figure.colorbar(collection)
        self.canvas.draw()

    @staticmethod
    def draw_simplex(ax, simplex, color):
        for (p, q) in itertools.combinations(simplex, 2):
            ax.plot([p[0], q[0]], [p[1], q[1]], [p[2], q[2]], color=color)

class Pair(object):
    def __init__(self, birth, death, birth_pos, death_pos):
        self.birth = birth
        self.death = death
        self.birth_pos = birth_pos
        self.death_pos = death_pos

    def lifetime(self):
        return self.death - self.birth

    @staticmethod
    def pairs_from_diagram(diagram):
        return [Pair(b, d, bp, dp)
                for b, d, bp, dp
                in zip(diagram.births, diagram.deaths,
                       diagram.birth_positions, diagram.death_positions)]

class PairsModel(QAbstractListModel):
    def __init__(self, diagram, parent=None):
        QAbstractListModel.__init__(self, parent)
        self.diagram = diagram
        self.pairs = Pair.pairs_from_diagram(diagram)
        self.pairs.sort(key=operator.methodcaller("lifetime"), reverse=True)
        self.filtered_pairs = self.pairs

    def reset_filter(self):
        self.filtered_pairs = self.pairs

    def apply_filter(self, text, func):
        if text == "":
            return
        threshold = float(text)
        self.filtered_pairs = [pair for pair in self.filtered_pairs
                               if func(pair, threshold)]

    def rowCount(self, _ = None):
        return len(self.filtered_pairs)

    def data(self, index, role):
        def format_pair(pair):
            return "({:9f}, {:9f})".format(pair.birth, pair.death)

        if not index.isValid():
            return QVariant()
        if index.row() >= self.rowCount(None):
            return QVariant()

        if role == QtCore.Qt.DisplayRole:
            return QVariant(format_pair(self.filtered_pairs[index.row()]))

        return QVariant()

if __name__ == "__main__":
    main()
