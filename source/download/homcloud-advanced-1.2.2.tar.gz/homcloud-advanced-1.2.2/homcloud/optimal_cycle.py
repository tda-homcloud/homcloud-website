import argparse
import functools
import sys
import json
from itertools import chain
from collections import namedtuple
import re

import numpy as np
import pulp

from homcloud.advanced import __version__
from homcloud.full_ph_tree import SpatialSearcher
from homcloud.diagram import PD
from homcloud.visualize_3d import ParaViewDrawer, boundary_of_connected_simplices
import homcloud.utils as utils


_debug_mode = False


def argument_parser():
    p = argparse.ArgumentParser(description="Compute volume optimal cycles")
    p.add_argument("-V", "--version", action="version", version=__version__)
    p.add_argument("-d", "--degree", type=int, required=True, help="degree of PH")
    p.add_argument("-x", type=float, help="birth time of the pair")
    p.add_argument("-y", type=float, help="death time of the pair")
    p.add_argument("-X", "--x-range", type=utils.parse_range, help="birth time of the pair")
    p.add_argument("-Y", "--y-range", type=utils.parse_range, help="death time of the pair")
    p.add_argument("-c", "--cutoff-radius", type=float, help="cut-off radius in R^n")
    p.add_argument("-T", "--type", default="volume",
                   help="type of optimal cycle (now only volume is available)")
    p.add_argument("-j", "--json-output", help="output in json format")
    p.add_argument("-v", "--vtk-output", help="output in vtk format")
    p.add_argument("-P", "--invoke-paraview", default=False, action="store_true",
                   help="invoke paraview for visualization")
    p.add_argument("-n", "--retry", type=int, default=0, help="number of retry")
    p.add_argument("-C", "--optimal-cycle-children", default=False, type=utils.parse_bool)
    p.add_argument("--integer-programming", default=False, type=utils.parse_bool,
                   help="use integer programming (on/*off*)")
    p.add_argument("--debug", default=False, type=utils.parse_bool,
                   help="debug mode (on/*off*)")
    p.add_argument("--solver", help="LP solver")
    p.add_argument("--constrain-on-birth-simplex", default=False,
                   action="store_true", help="constrain on the birth simplex")
    p.add_argument("--skip-infeasible", default=False, type=utils.parse_bool,
                   help="skip infeasible (on/*off*)")
    p.add_argument("input", help="input file")
    return p


def main(args=None):
    if not args:
        args = argument_parser().parse_args()

    def vtk_required():
        return args.vtk_output or args.invoke_paraview

    check_args(args)
    diagram = PD.load_from_indexed_diphafile(args.input, args.degree)
    index_map = diagram.index_map
    vocfinder = VolumeOptimalCycleFinder.from_args(diagram, args)
    spatial_searcher = SpatialSearcher.from_diagram(diagram)
    
    if args.x is not None and args.y is not None:
        query = PointQuery(args.x, args.y, spatial_searcher, vocfinder,
                           skip_infeasible=args.skip_infeasible,
                           optimal_cycle_children=args.optimal_cycle_children)
    elif args.x_range and args.y_range:
        query = RectangleQuery(args.x_range, args.y_range, spatial_searcher, vocfinder,
                               skip_infeasible=args.skip_infeasible,
                               optimal_cycle_children=args.optimal_cycle_children)
    else:
        print("Please specify (x and y) or (x_range and y_range)")
        exit(11)

    query.invoke()

    if query.num_infeasible:
        print("Num infeasible: {}".format(query.num_infeasible), file=sys.stderr)

    if vtk_required():
        drawer = prepare_drawer_for_paraview(index_map)
        query.draw(drawer)

        if args.vtk_output:
            drawer.output(args.vtk_output)
        if args.invoke_paraview:
            drawer.invoke()
    if args.json_output:
        with open(args.json_output, "w") as f:
            json.dump(query.to_jsondict(), f)


class Query(object):
    def __init__(self, spatial_searcher, vocfinder,
                 skip_infeasible=False, optimal_cycle_children=False):
        self.spatial_searcher = spatial_searcher
        self.vocfinder = vocfinder
        self.optimal_volumes = []
        self.children_volumes = []
        self.num_infeasible = 0
        self.skip_infeasible = skip_infeasible
        self.optimal_cycle_children = optimal_cycle_children
        self.children_index = 1
 
    def query_pair(self, birth, death):
        optimal_volume, status = self.vocfinder.query(birth, death)
        if not optimal_volume:
            print(status.message, file=sys.stderr)
            if status.message == "Infeasible" and self.skip_infeasible:
                self.num_infeasible += 1
                return
            else:
                exit(status.code)

        # optimal_volume.draw(drawer)
        if self.optimal_cycle_children:
            optimal_volume.children_volumes = self.query_children(optimal_volume)
        self.optimal_volumes.append(optimal_volume)

    def query_children(self, volume):
        print(volume)
        children_volumes = []
        for (birth_child, death_child) in volume.children_pairs:
            child_volume, status = self.vocfinder.query(birth_child, death_child)
            if not child_volume:
                print(status.message, file=sys.stderr)
                continue
            child_volume.child_index = str(self.children_index)
            # child_volume.draw(drawer)
            children_volumes.append(child_volume)
            self.children_index += 1
        return children_volumes

    def draw(self, drawer):
        for volume in self.optimal_volumes:
            volume.draw(drawer)

    def to_jsondict(self):
        return {
            "format-version": Query.FORMAT_VERSION,
            "query": self.queryinfo_jsondict(),
            "dimension": self.vocfinder.diagram.index_map.dimension,
            "num-volumes": len(self.optimal_volumes),
            "num-infeasible": self.num_infeasible,
            "result": self.result_jsondicts(),
        }

    def common_queryinfo_jsondict(self):
        return {
            "query-target": "volume-optimal-cycle",
            "degree": self.vocfinder.degree,
            "cutoff-radius": self.vocfinder.cutoff_radius,
            "num-retry": self.vocfinder.num_retry,
            "integer-programming": self.vocfinder.integer_programming,
            "constrain-on-birth-simplex": self.vocfinder.constrain_birth,
            "skip-infeasible": self.skip_infeasible,
            "optimal-cycle-children": self.optimal_cycle_children,
            "solver": self.vocfinder.solver_name(),
        }
        
    FORMAT_VERSION = 1

    def result_jsondicts(self):
        return [volume.to_jsondict() for volume in self.optimal_volumes]

class PointQuery(Query):
    def __init__(self, x, y, spatial_searcher, vocfinder, **kwargs):
        super().__init__(spatial_searcher, vocfinder, **kwargs)
        self.x = x
        self.y = y

    def invoke(self):
        birth, death = self.spatial_searcher.nearest_pair(self.x, self.y)
        self.query_pair(birth, death)

    def queryinfo_jsondict(self):
        dic = {"query-type": "single", "birth": self.x, "death": self.y }
        dic.update(self.common_queryinfo_jsondict())
        return dic


class RectangleQuery(Query):
    def __init__(self, x_range, y_range, spatial_searcher, vocfinder, **kwargs):
        super().__init__(spatial_searcher, vocfinder, **kwargs)
        self.x_range = x_range
        self.y_range = y_range

    def invoke(self):
        for (birth, death) in self.spatial_searcher.in_rectangle(
                self.x_range[0], self.x_range[1], self.y_range[0], self.y_range[1]
        ):
            if birth.time() == death.time():
                continue
            if _debug_mode:
                print((birth.time(), death.time()))

            self.query_pair(birth, death)

    def queryinfo_jsondict(self):
        dic = {
            "query-type": "rectangle",
            "birth-range": self.x_range, "death-range": self.y_range
        }
        dic.update(self.common_queryinfo_jsondict())
        return dic

        return dict()

class VolumeOptimalCycleFinder(object):
    def __init__(self, diagram, degree, cutoff_radius, solver, constrain_birth,
                 num_retry, integer_programming=False):
        self.diagram = diagram
        self.degree = degree
        self.cutoff_radius = cutoff_radius
        self.solver = solver
        self.constrain_birth = constrain_birth
        self.num_retry = num_retry
        self.integer_programming = integer_programming

    @staticmethod
    def from_args(diagram, args):
        return VolumeOptimalCycleFinder(diagram, args.degree, args.cutoff_radius,
                                        args.solver, args.constrain_on_birth_simplex,
                                        args.retry, args.integer_programming)

    def query(self, birth, death):
        for n in range(self.num_retry + 1):
            optimal_volume, status = self.query_once(birth, death, n)
            if optimal_volume:
                return (optimal_volume, status)
        return (None, status)

    def query_once(self, birth, death, n):
        included_simplex_func = functools.partial(
            included_simplex, (birth.centroid() + death.centroid()) / 2,
            self.cutoff_radius, n,
        )

        if not included_simplex_func(death):
            return None, QueryStatus("Death simplex not included in cutoff sphere", 10)

        lp_volume_optimal = LpForVolumeOptimalCycle(
            self.diagram, self.degree, birth, death, included_simplex_func,
            self.integer_programming
        )
        lp_volume_optimal.collect_constrains()
        return lp_volume_optimal.solve_pulp_problem(select_solver(self.solver),
                                                    self.constrain_birth)

    def solver_name(self):
        if self.solver:
            return type(select_solver(self.solver)).__name__
        else:
            return self.default_solver_name()

    @staticmethod
    def default_solver_name():
        return type(pulp.LpSolverDefault).__name__

QueryStatus = namedtuple("QueryStatus", ["message", "code"])


def select_solver(solver_name):
    if solver_name is None:
        return None
    if solver_name == "coin":
        return pulp.COIN()
    if solver_name == "cplex":
        return pulp.CPLEX()
    if solver_name == "gurobi":
        return pulp.GUROBI()
    if solver_name == "glpk":
        return pulp.GLPK()
    if solver_name == "coinmp-dll":
        return pulp.COINMP_DLL()
    if solver_name == "cplex-dll":
        return pulp.CPLEX_DLL()
    raise RuntimeError("Unknown solver {}".format(solver_name))


def included_simplex(center, radius, n, simplex):
    if radius is None:
        return True
    for vertex in simplex.vertices():
        if np.linalg.norm(center - vertex.coord()) < radius * (2**n):
            return True
    return False


class LpForVolumeOptimalCycle(object):
    def __init__(self, diagram, degree, birth, death,
                 func_included_simplex, integer_programming):
        self.boundary_on = dict()
        self.lpvars = set()
        self.diagram = diagram
        self.index_map = diagram.index_map
        self.degree = degree
        self.birth = birth
        self.death = death
        self.included_simplex = func_included_simplex
        self.lpvar_type = "Integer" if integer_programming else "Continuous"

    def collect_constrains(self):
        for i in range(self.birth.index, self.death.index + 1):
            simplex = self.index_map.simplex(i)
            if simplex.dim() == self.degree:
                self.boundary_on[simplex.key()] = list()
            elif simplex.dim() == self.degree + 1 and self.included_simplex(simplex):
                self.add_volume_simplex(simplex)
        self.lpvars.add(self.death.index)

    def add_volume_simplex(self, simplex):
        for (key, sign) in simplex.boundary_keys_orientation():
            if key in self.boundary_on:
                self.boundary_on[key].append((sign, simplex.index))
                self.lpvars.add(simplex.index)

    def solve_pulp_problem(self, solver, use_constrain_on_birth_simplex):
        prob = pulp.LpProblem("Optimal Cycle", pulp.LpMinimize)
        xs = pulp.LpVariable.dicts("x", (self.lpvars, ), -1.0, 1.0, self.lpvar_type)
        ys = pulp.LpVariable.dicts("y", (self.lpvars, ), 0.0, 1.0, self.lpvar_type)

        def add_constrain_on_birth_simplex():
            nonlocal prob
            if use_constrain_on_birth_simplex:
                z = pulp.LpVariable("z", 0.0, 1.0, "Integer")
                prob += pulp.lpSum(sign * xs[index] for (sign, index) in
                                   self.boundary_on[self.birth.key()]) == 1 - 2 * z

            del self.boundary_on[self.birth.key()]

        def add_constrains_abs_x_lt_y():
            nonlocal prob
            for (x, y) in zip(xs.values(), ys.values()):
                prob += x - y <= 0.0
                prob += x + y >= 0.0

        def add_constrains_on_banned_simplices():
            nonlocal prob
            for constrain in self.boundary_on.values():
                if not constrain:
                    continue
                prob += pulp.lpSum(sign * xs[index] for (sign, index) in constrain) == 0

        def add_constrain_on_death_simplex():
            nonlocal prob
            prob += xs[self.death.index] == 1

        def volume_optimal_simplices():
            return [self.index_map.simplex(i) for i in self.lpvars
                    if ys[i].varValue >= 0.0001]

        prob += pulp.lpSum(ys.values())
        add_constrain_on_birth_simplex()
        add_constrains_abs_x_lt_y()
        add_constrains_on_banned_simplices()
        add_constrain_on_death_simplex()

        # workaround for cplex and pulp
        try:
            status = prob.solve(solver)
        except pulp.solvers.PulpSolverError as err:
            if re.search("infeasible", err.args[0]):
                return (None, QueryStatus("Infeasible", 2))
            else:
                raise err

        if status == pulp.LpStatusOptimal:
            return (OptimalVolume(volume_optimal_simplices(),
                                  self.birth, self.death, self.diagram),
                    QueryStatus("OK", 0))
        else:
            return (None, QueryStatus(pulp.LpStatus[status], -(status - 1)))


class OptimalVolume(object):
    def __init__(self, simplices, birth, death, diagram):
        self.simplices = simplices
        self.birth = birth
        self.death = death
        self.diagram = diagram
        self.child_index = "0"
        self.children_volumes = []
        self.children_pairs = self.compute_children_pairs()
        self.boundary_simplices = boundary_of_connected_simplices(
            frozenset(simplex.key()) for simplex in self.simplices
        )

    def draw(self, drawer):
        if self.child_index == "0":
            volume_color = drawer.color_scalars[0]
            boundary_color = drawer.color_scalars[1]
        else:
            volume_color = drawer.color_scalars[2]
            boundary_color = drawer.color_scalars[3]

        self.draw_simplices(drawer, volume_color)
        self.draw_boundary(drawer, boundary_color)
        self.draw_birth_simplex(drawer)
        self.draw_death_simplex(drawer)

        for child_volume in self.children_volumes:
                child_volume.draw(drawer)

    def draw_simplices(self, drawer, color):
        for simplex in self.simplices:
            drawer.draw_simplex(simplex.key(), color, isboundary="0", issimplex="1",
                                isbirth="0", isdeath="0", children_index=self.child_index)

    def draw_boundary(self, drawer, color):
        for b in self.boundary_simplices:
            drawer.draw_simplex(b, color, isboundary="1", issimplex="0",
                                isbirth="0", isdeath="0", children_index=self.child_index)

    def draw_birth_simplex(self, drawer):
        drawer.draw_simplex(self.birth.key(), drawer.birth_color(),
                            isboundary="0", issimplex="0",
                            isbirth="1", isdeath="0", children_index=self.child_index)

    def draw_death_simplex(self, drawer):
        drawer.draw_simplex(self.death.key(), drawer.death_color(),
                            isboundary="0", issimplex="0",
                            isbirth="0", isdeath="1", children_index=self.child_index)

    def compute_children_pairs(self):
        ret = []
        for simplex in self.simplices:
            if self.death == simplex:
                continue
            where = np.argwhere(self.diagram.death_indices == simplex.index)
            if where.size == 0:
                continue
            birth_simplex = self.diagram.index_map.simplex(self.diagram.birth_indices[where[0, 0]])
            if birth_simplex.time() == simplex.time():
                continue
            ret.append((birth_simplex, simplex))
        return ret

    def to_jsondict(self):
        index_map = self.diagram.index_map
        

        return {
            "birth-time": self.birth.time(), "death-time": self.death.time(),
            "points": self.points(),
            "simplices": self.volume_simplices(),
            "boundary": self.boundary(),
            "boundary-points": self.boundary_points(),
            "children": self.children(),
        }

    def points(self):
        return self._resolve_points(set(chain.from_iterable(s.key() for s in self.simplices)))

    def volume_simplices(self):
        return utils.deep_tolist([simplex.point_coords() for simplex in self.simplices])

    def boundary(self):
        return [[self.diagram.index_map.points[i].tolist() for i in s]
                for s in self.boundary_simplices]

    def boundary_points(self):
        return self._resolve_points(set(chain.from_iterable(self.boundary_simplices)))

    def _resolve_points(self, point_indices):
        return [self.diagram.index_map.points[i].tolist() for i in point_indices]

    def children(self):
        if self.children_volumes:
            return [
                child_volume.to_jsondict() for child_volume in self.children_volumes
            ]
        else:
            return [
                {"birth-time": birth.time(), "death-time": death.time()}
                for (birth, death) in self.children_pairs
            ]


def prepare_drawer_for_paraview(index_map):
    return ParaViewDrawer(4, index_map.points,
                          ["isboundary", "issimplex", "isbirth",
                           "isdeath", "children_index"])


def check_args(args):
    assert args.degree >= 0


if __name__ == "__main__":
    main()
