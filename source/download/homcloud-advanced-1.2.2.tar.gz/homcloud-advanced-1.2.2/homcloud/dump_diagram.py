import argparse
from homcloud.index_map_advanced import MapType

import homcloud.utils as utils
from homcloud.advanced import __version__

def argument_parser():
    """Returns the parser of args
    """
    p = argparse.ArgumentParser(description="Dump pairs in dipha's diagram")
    p.add_argument("-V", "--version", action="version", version=__version__)
    utils.add_arguments_for_load_diagrams(p)
    p.add_argument("-o", "--output", help="output text file")
    p.add_argument("-S", "--show-simplices", type=utils.parse_bool, default=True,
                   help="show birth/death simplices (yes/no, default:yes)")
    p.add_argument("input", nargs="*", help="input dipha diagram")
    return p

def format_pixel(at):
    return "(" + ",".join([str(x) for x in at]) + ")"

def format_simplex(vertices):
    return "{" + ",".join([format_pixel(vertex) for vertex in vertices]) + "}"

def output_io(args):
    import sys
    if args.output:
        return open(args.output, "w")
    else:
        return sys.stdout

def write_pairs_with_positions(diagram, io):
    if diagram.filtration_type == MapType.bitmap:
        formatter = format_pixel
    elif diagram.filtration_type == MapType.alpha:
        formatter = format_simplex
    else:
        raise "Unkndown index map format"

    for (birth, death, birth_pos, death_pos) in zip(diagram.births,
                                                    diagram.deaths,
                                                    diagram.birth_positions,
                                                    diagram.death_positions):
        io.write("{} {} {} {}\n".format(birth, death,
                                        formatter(birth_pos), formatter(death_pos)))

def write_pairs(diagram, io):
    for (birth, death) in zip(diagram.births, diagram.deaths):
        io.write("{} {}\n".format(birth, death))

def main(args=None):
    args = args or argument_parser().parse_args()
    diagram = utils.load_diagrams(args.type, args.input, args.degree, args.negate)

    if diagram.filtration_type and args.show_simplices:
        write_pairs_with_positions(diagram, output_io(args))
    else:
        write_pairs(diagram, output_io(args))



if __name__ == "__main__":
    main()
