# pylint: disable=R0204
import re
import enum
import os
import subprocess
import sys

import numpy as np

from homcloud.diagram import PD


def standardize(pict):
    """Standardize pixel values of the picture

    Args:
    pict -- 2D ndarray
    """
    average = np.average(pict)
    sd = np.std(pict)
    return (pict - average) / sd


def load_diagram(typestr, path, degree):
    filetype = estimate_diagram_file_type(typestr, path)
    if filetype == FileType.dipha_diagram:
        return PD.load_from_diphafile(path, degree)
    if filetype == FileType.idipha_diagram:
        return PD.load_from_indexed_diphafile(path, degree)
    if filetype == FileType.text:
        return PD.load_from_textfile(path)
    if filetype == FileType.persistence_merge_tree:
        return PD.load_from_pmtfile(path, degree)
    if filetype == FileType.p2mt:
        return PD.load_from_p2mtfile(path, degree)
    raise ValueError("Unkown file format: {}", path)


def load_diagrams(typestr, paths, degree, negate):
    """Load diagrams from paths, merge them, and return merged diagram

    Args:
    typestr -- the type of input file, "dipha", "text", "idipha", or None(autodetect)
    paths -- the list of input files
    degree -- degree of persistence homology (not requred for "text" format)
    negate -- flip sign of birth/death times if True
    """
    diagrams = [load_diagram(typestr, path, degree) for path in paths]
    if len(diagrams) != 1:
        diagram = PD.merge(diagrams)
    else:
        diagram = diagrams[0]

    if negate:
        diagram.negate_birth_death_time()

    return diagram


def add_arguments_for_load_diagrams(parser):
    parser.add_argument("-d", "--degree", type=int, required=True,
                        help="degree of PH")
    parser.add_argument("-T", "--type",
                        help="input file format (dipha, idipha, text) (default: autodetect)")
    parser.add_argument("-N", "--negate", default=False, action="store_true",
                        help="flip the sign of birth/death times for superlevel persistence (default: False)")


def add_arguments_for_histogram_rulers(parser):
    parser.add_argument("-x", "--x-range", type=parse_range,
                        help="birth range")
    parser.add_argument("-X", "--xbins", type=int, default=128,
                        help="number of bins in birth-axis")
    parser.add_argument("-y", "--y-range", type=parse_range, default=None,
                        help="death range")
    parser.add_argument("-Y", "--ybins", type=int, default=None,
                        help="number of bins in death-axis")


def add_arguments_for_gaussian_diffusion(parser):
    parser.add_argument("-D", "--gaussian-sd", type=float, required=True,
                        help="standard deviation of gaussian diffusion")


def add_arguments_for_kernel_weight(parser):
    parser.add_argument("-C", type=float, help="weight constant C")
    parser.add_argument("-p", type=float, default=1.0, help="weight constant p")


FLOAT_REGEXP = r"[+-]?\d+(\.\d+)?"
RANGE_REGEXPS = [
    re.compile(r"\A(?P<begin>{0}):(?P<end>{0})\Z".format(FLOAT_REGEXP)),
    re.compile(r"\A\[(?P<begin>{0}):(?P<end>{0})\]\Z".format(FLOAT_REGEXP)),
]


def parse_range(string):
    for regexp in RANGE_REGEXPS:
        m = regexp.match(string)
        if m:
            return (float(m.group("begin")), float(m.group("end")))
    raise ValueError("{} cannot be parsed as range".format(string))


def parse_bool(string):
    s = string.lower()
    if s == "true" or s == "yes" or s == "1" or s == "on":
        return True
    if s == "false" or s == "no" or s == "0" or s == "off":
        return False
    raise ValueError("{} cannot be parsed as boolean".format(string))


def parse_color(string):
    if re.match(r"#[0-9a-fA-F]{6}\Z", string):
        return tuple(int(string[i:i + 2], 16) for i in [1, 3, 5])
    raise ValueError("{} cannot be parsed as color".format(string))


@enum.unique
class FileType(enum.Enum):
    text = 0
    dipha_complex = 1
    dipha_diagram = 2
    idipha_complex = 3
    idipha_diagram = 4
    persistence_merge_tree = 5
    p2mt = 6
    unknown = -1


def estimate_diagram_file_type(typestr, path):
    """Estimate file type from typestr and path and return one of the followings:

    text, dipha_diagram, idipha_diagram in FileType

    if the file type cannot be determined, returns FileType.unknown
    args:
    typestr -- a string representing filetype, one of: None, "idipha", "dipha", "text"
    path -- a filepath string
    """
    TABLE_TYPENAME = {
        "idipha": FileType.idipha_diagram,
        "dipha": FileType.dipha_diagram,
        "text": FileType.text,
        "pmt": FileType.persistence_merge_tree,
        "p2mt": FileType.p2mt,
    }
    TABLE_EXTENSION = {
        ".idiagram": FileType.idipha_diagram,
        ".diagram": FileType.dipha_diagram,
        ".pmt": FileType.persistence_merge_tree,
        ".p2mt": FileType.p2mt,
        ".txt": FileType.text,
    }

    _, ext = os.path.splitext(path)
    return TABLE_TYPENAME.get(typestr) or TABLE_EXTENSION.get(ext) or FileType.unknown


def boundary_of_simplex(simplex):
    return [simplex.difference([el]) for el in simplex]


def invoke_paraview(*args, nohup=True):
    devnull = subprocess.DEVNULL
    redirect = {"stdin": devnull, "stdout": devnull, "stderr": devnull}
    program_name = os.environ.get("HOMCLOUD_PARAVIEW_PROGRAMNAME", "paraview")
    if sys.platform.startswith("darwin"):
        if nohup:
            subprocess.check_call(["open", "-a", program_name] + list(args), **redirect)
        else:
            subprocess.check_call(["open", "-a", program_name, "-W"] + list(args), **redirect)
    elif sys.platform.startswith("win"):
        if nohup:
            subprocess.Popen([program_name] + list(args), **redirect)
        else:
            subprocess.check_call([program_name] + list(args), **redirect)
    else:
        if nohup:
            subprocess.Popen(["nohup", program_name] + list(args), **redirect)
        else:
            subprocess.check_call(["nohup", program_name] + list(args), **redirect)


def deep_tolist(lst):
    """Convert ndarray to python's list recursively.

    This function is useful to convert data into json/msgpack format.

    TODO: support dict.
    """
    if isinstance(lst, np.ndarray):
        return lst.tolist()
    if isinstance(lst, list):
        return [deep_tolist(l) for l in lst]
    return lst
