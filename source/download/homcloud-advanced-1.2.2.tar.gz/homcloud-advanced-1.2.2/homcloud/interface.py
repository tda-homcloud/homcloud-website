from tempfile import NamedTemporaryFile, TemporaryDirectory
import shutil
import subprocess
import sys

import numpy as np
from forwardable import forwardable
import matplotlib.pyplot as plt

import homcloud.alpha_filtration as alpha_filtration
import homcloud.pict.binarize as binarize
import homcloud.diagram as homdiag
import homcloud.plot_PD as plot_PD
import homcloud.bitmap_complex as bitmap_complex
import homcloud.full_ph_tree as full_ph_tree
import homcloud.index_map_advanced 
import homcloud.utils as utils
from homcloud.optimal_cycle import VolumeOptimalCycleFinder
from homcloud.full_ph_tree import SpatialSearcher


_tempdir_path = None


def tempdir():
    global _tempdir_path
    if not _tempdir_path:
        _tempdir_path = TemporaryDirectory()

    return _tempdir_path


def tempfile(suffix):
    file = NamedTemporaryFile(suffix=suffix, dir=tempdir().name, delete=False)
    file.close()
    return file.name


class PDs(object):
    def __init__(self, path):
        self.path = path
        self.diagrams = dict()
        self.index_map = None

    @staticmethod
    def from_alpha_filtration(pointcloud,
                              weight=False, no_squared=False,
                              subsets=False, check_acyclicity=False,
                              parallels=1, save_to=None):
        input_data = pointcloud.astype(dtype=float)
        num_points, dim = pointcloud.shape
        if isinstance(weight, np.ndarray):
            input_data = np.hstack([input_data,
                                    weight.reshape(num_points, 1)])
            weight = True
        elif weight is True:
            dim -= 1

        if isinstance(subsets, np.ndarray):
            input_data = np.hstack([input_data, subsets.reshape(num_points, 1)])
            subsets = True
        elif subsets is True:
            dim -= 1

        filtration = alpha_filtration.create_alpha_shape(
            input_data, dim, weight, subsets
        ).create_filtration(no_squared)

        if check_acyclicity:
            filtration.check_for_relative_filtration()

        filtration.indexize()
        if save_to is None:
            save_to = tempfile(".idiagram")
        filtration.compute_diagram_and_save(save_to, parallels)        
        return PDs(save_to)

    @staticmethod
    def from_bitmap_levelset(array, mode, save_to):
        if mode == "sublevel":
            flip_sign = False
        elif mode == "superlevel":
            array = -array
            flip_sign = True
        bitmap = bitmap_complex.BitmapComplex(array, flip_sign)
        bitmap.indexize()
        if not save_to:
            save_to = tempfile(".idiagram")
        bitmap.compute_diagram_and_save(save_to)
        return PDs(save_to)

    @staticmethod
    def from_bitmap_distance_function(binary_pict, signed=False, metric="manhattan",
                                      save_to=None):
        bitmap = binarize.distance_bitmap(binary_pict, metric, signed)
        bitmap.indexize()
        if not save_to:
            save_to = tempfile(".idiagram")
        bitmap.compute_diagram_and_save(save_to)
        return PDs(save_to)

    def save(self, dest):
        shutil.copyfile(self.path, dest)

    def __getitem__(self, key):
        return self.dth_diagram(key)

    def dth_diagram(self, d):
        if d not in self.diagrams:
            self.diagrams[d] = PD(homdiag.PD.load_from_indexed_diphafile(self.path, d))

        return self.diagrams[d]

    def invoke_gui_plotter(self, d):
        subprocess.Popen([sys.executable, "-m", "homcloud.plot_PD_gui", "-d", str(d),
                          self.path])


@forwardable()
class PD(object):
    def __init__(self, pd):
        self.pd = pd
        self.spatial_searcher = None

    def birth_death_times(self):
        return self.pd.births, self.pd.deaths

    def_delegators("pd", "births,deaths,birth_positions,death_positions")

    def histogram(self, x_range=None, x_bins=128, y_range=None, y_bins=None,):
        rulers = homdiag.Ruler.create_xy_rulers(x_range, x_bins, y_range, y_bins, self.pd)
        hist = homdiag.PDHistogram(self.pd, *rulers)
        return Histogram(hist)

    def phtrees(self, save_to=None):
        if save_to is None:
            save_to = tempfile(".pht")

        if self.pd.index_map.type() != homcloud.index_map_advanced.MapType.alpha:
            raise(RuntimeError("PHTrees is computable only from an alpha filtration"))

        if self.pd.degree != self.pd.index_map.dimension - 1:
            raise(RuntimeError("degree should equal dimension - 1"))

        pht = full_ph_tree.PHTrees(self.pd, self.pd.degree)
        pht.construct_tree()
        with open(save_to, "wb") as f:
            full_ph_tree.write_phtree(f, pht, self.pd)

        return PHTrees(save_to)

    def pair(self, nth):
        return Pair(
            self, self.pd.masked_birth_indices[nth], self.pd.masked_death_indices[nth],
            self.pd.birth_positions[nth] if self.pd.index_map else None,
            self.pd.death_positions[nth] if self.pd.index_map else None
        )

    def get_spatial_searcher(self):
        if not self.spatial_searcher:
            self.spatial_searcher = SpatialSearcher.from_diagram(self.pd)
        return self.spatial_searcher


    @staticmethod
    def empty():
        return PD(homdiag.PD.empty_pd())


class Pair(object):
    def __init__(self, diagram, birth_index, death_index, birth_position, death_position):
        self.diagram = diagram
        self.index_map = self.diagram.pd.index_map
        self.birth_index = birth_index
        self.death_index = death_index
        self.birth_position = birth_position
        self.death_position = death_position

    def birth_time(self):
        return self.index_map.levels[self.birth_index]

    def death_time(self):
        return self.index_map.levels[self.death_index]

    def optimal_volume(self, cutoff_radius=None, solver=None, constrain_birth=False,
                       num_retry=4, integer_programming=False):
        optimal_volume, status = VolumeOptimalCycleFinder(
            self.diagram.pd, self.diagram.pd.degree,
            cutoff_radius, solver, constrain_birth, num_retry, integer_programming
        ).query(
            self.index_map.simplex(self.birth_index),
            self.index_map.simplex(self.death_index)
        )
        if not optimal_volume:
            raise(RuntimeError(status.message))

        return OptimalVolume(self.diagram, optimal_volume)

    def __eq__(self, other):
        return (isinstance(other, Pair)
                and self.diagram == other.diagram
                and self.birth_index == other.birth_index
                and self.death_index == other.death_index)

@forwardable()
class OptimalVolume(object):
    def __init__(self, diagram, optimal_volume):
        self.diagram = diagram
        self.optimal_volume = optimal_volume

    def_delegators("optimal_volume", "points,boundary_points,boundary")

    def birth_time(self):
        return self.optimal_volume.birth.time()

    def death_time(self):
        return self.optimal_volume.death.time()

    def simplices(self):
        return self.optimal_volume.volume_simplices()

    def children(self):
        return [
            Pair(self.diagram, birth.index, death.index,
                 birth.point_coords(), death.point_coords())
            for (birth, death) in self.optimal_volume.children_pairs
        ]

@forwardable()
class Histogram(object):
    def __init__(self, orig):
        self.orig = orig

    @property
    def values(self):
        return self.orig.values

    @values.setter
    def values(self, values):
        self.orig.values = values

    def_delegators('orig', 'x_range,y_range,x_bins,y_bins')

    def plot(self, colorbar=None, style="colorhistogram",
             title="", unit_name=None, font_size=None, aspect="auto", fig=None):
        plotter = plot_PD.PDPlotter.find_plotter(style)(
            self.orig, self._zspec(colorbar), plot_PD.AuxPlotInfo(
                title, unit_name, font_size, aspect
            )
        )
        plotter.plot(*self._fig_ax(fig))

    @staticmethod
    def _zspec(colorbar):
        type = colorbar.get("type", "linear")
        vmax = colorbar.get("max")
        vmin = colorbar.get("min")
        colormap = plt.get_cmap(colorbar["colormap"]) if "colormap" in colorbar else None
        if type == "linear":
            return plot_PD.ZSpec.Linear(vmax, vmin, colormap)
        elif type == "log":
            return plot_PD.ZSpec.Log(vmax, vmin, colormap)
        elif type == "loglog":
            return plot_PD.ZSpec.LogLog(vmax, vmin, colormap)
        elif type == "linear-midpoint":
            return plot_PD.ZSpec.LinaerMidPoint(colorbar["midpoint"], vmax, vmin, colormap)
        elif type == "power":
            return plot_PD.ZSpec.Power(colorbar["p"], vmax, vmin, colormap)
        else:
            raise(RuntimeError("unknown colorbar type: {}").format(type))

    @staticmethod
    def _fig_ax(fig):
        if fig is None:
            return plt.subplots()
        else:
            return (fig, fig.add_subplot())

class PHTrees(object):
    def __init__(self, path):
        self.path = path
        self.resolver = None

    def save(self, dest):
        shutil.copyfile(self.path, dest)

    def _resolver(self):
        if self.resolver is None:
            with open(self.path, "rb") as f:
                self.resolver = full_ph_tree.TreeResolver.load(f)
        return self.resolver

    def query_point(self, x, y):
        return self._resolver().query_node(x, y)

    def query_rectangle(self, x_range, y_range):
        return self._resolver().query_nodes_in_rectangle(x_range[0], x_range[1],
                                                         y_range[0], y_range[1])

    def show_volume(self, node):
        path = tempfile(".vtk")
        node.draw_descendants_volumes(node.index_map.points, path, False, False)
        utils.invoke_paraview(path, nohup=False)

    def show_volumes(self, nodes):
        path = tempfile(".vtk")
        self._resolver().draw_volumes_of_nodes(nodes, path, True, True)
        utils.invoke_paraview(path, nohup=False)

    def show_volume_at(self, x, y):
        self.show_volume(self.query_point(x, y))

    def show_volumes_in(self, x_range, y_range):
        self.show_volumes(self.query_rectangle(x_range, y_range))

        
