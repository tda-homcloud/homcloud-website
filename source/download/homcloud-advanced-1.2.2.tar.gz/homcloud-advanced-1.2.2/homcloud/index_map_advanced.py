import json
import enum
import functools

import numpy as np


@enum.unique
class MapType(enum.Enum):
    bitmap = 1
    alpha = 2


class IndexMap(object):
    """A class representing a map from index to the real birth time (called a level).

    This class is a baseclass of IndexMapForBitmap and IndexMapForAlphaFiltration.
    The main purpose is to save and load index-map information to and from
    a file or binary string.

    Instance variables:
    levels -- 1D ndarray from index birth time of each pixel/simplex to
              real birth time of each pixel/simplex.
              index birth times are 0,1, ..., number-of-pixels/simplices - 1
    dimension -- dimension of input data, 2, 3, or greater integers
    format_version -- index-map file format version number, int
    """

    def __init__(self, levels, dim, format_version):
        self.levels = levels
        self.dimension = dim
        self.format_version = format_version

    def resolve_levels(self, index):
        """Convert the list of indices to the list of birth/death times

        Args:
        index -- a list of indices (ndarray whose dtype is float)
        """
        return self.levels[np.array(index, dtype=int)]

    def resolve_level(self, index):
        """Convert a single index to the birth radius

        Args:
        index -- an integer of index
        """
        return self.levels[index]

    def resolve_pair(self, pair):
        """Convert a pair of indices to the birth and death time

        Args:
        pair -- a pair of indices
        """
        return (self.levels[pair[0]], self.levels[pair[1]])

    @staticmethod
    def load_from_json(f):
        """Load an index map from an io object

        Args:
        f -- an io object
        """
        return IndexMap.load_from_dict(json.load(f))

    @staticmethod
    def load_from_jsonfile(path):
        """Load an index map from the file whose name is path

        Args:
        path -- input file path
        """
        with open(path) as f:
            return IndexMap.load_from_json(f)

    @staticmethod
    def load_from_dict(dict_):
        """Load an index map from the given dict object
        """
        dim = dict_.get("dimension", None)
        format_version = dict_.get("format-version", 0)
        if dict_["type"] == "bitmap":
            return IndexMapForBitmap(np.array(dict_["positions"]),
                                     np.array(dict_["levels"]),
                                     dim, dict_.get("levels-sign-flipped"),
                                     format_version)
        if dict_["type"] == "alpha":
            return IndexMapForAlphaFiltration(np.array(dict_["levels"]),
                                              np.array(dict_["points"]),
                                              dict_["simplices"],
                                              dim, format_version)

    FORMAT_VERSION = 2


class IndexMapForBitmap(IndexMap):
    """A class representing a map from index birth time to the real birth times for
    bitmap filtrations.

    Instance variables:
    positions -- n-D ndarray represents a map from an index to the [x, y, ...]
                 coordinate of the pixel correspoinding the index
    levels_sign -- the sign of levels, for superlevel filtration, this is set to -1.0,
                 otherwise, this is set to 1.0. For old version (format_version <= 1),
                 this value is None.
    """

    def __init__(self, positions, levels, dim, levels_sign_flipped,
                 format_version=IndexMap.FORMAT_VERSION):
        self.positions = positions
        self.levels_sign_flipped = levels_sign_flipped
        IndexMap.__init__(self, levels, dim, format_version)

    def resolve(self, indices):
        """
        Returns a tuple of (real birth times) and (correspoding coordinates)
        computed from indices and map information.

        Args:
        indices -- 1D ndarray of int, the list of indices
        """
        indices = np.array(indices, dtype=int)
        return (self.levels[indices], self.positions[indices])

    def to_dict(self):
        """Return dict that represents the index object
        """
        return {
            "type": "bitmap",
            "positions": self.positions.tolist(),
            "levels": self.levels.tolist(),
            "levels-sign-flipped": self.levels_sign_flipped,
            "format-version": self.format_version,
            "dimension": self.dimension,
        }

    @staticmethod
    def type():
        return MapType.bitmap


class IndexMapForAlphaFiltration(IndexMap):
    """A class representing a map from index birth times to the real birth times for
    alpha filtrations.

    Instance variables:
    points -- list of coordinates of all points in the delaunay triagulation
    simplces -- list of simplices, indexed by the index-birth-time.
                In this variable, a simplex is repserented by the list of
                points. Each point is represented by an integer, the index
                in self.points.
    """

    def __init__(self, levels, points, simplices, dim, format_version=IndexMap.FORMAT_VERSION):
        self.points = points
        self.simplices = simplices
        IndexMap.__init__(self, levels, dim, format_version)

    def resolve(self, indices):
        """
        Returns a tuple of (real birth times) and (correspoding simplices)
        computed from indices and map information.

        Args:
        indices -- 1D ndarray of int, the list of indices
        """
        simplices = [[self.points[simplex_index]
                      for simplex_index in self.simplices[int(index)]]
                     for index in indices]
        return (self.levels[np.array(indices, dtype=int)], simplices)

    def to_dict(self):
        """Return dict that represents the index object
        """
        return {
            "type": "alpha",
            "levels": self.levels.tolist(),
            "points": self.points.tolist(),
            "simplices": self.simplices,
            "format-version": self.format_version,
            "dimension": self.dimension,
        }

    def resolve_simplex(self, simplex_index):
        simplex = self.simplices[simplex_index]
        return [self.points[point_index] for point_index in simplex]

    def centroid_of_simplex(self, simplex_index):
        return np.mean(self.resolve_simplex(simplex_index), axis=0)

    def simplex(self, i):
        return Simplex(i, self)

    @staticmethod
    def type():
        return MapType.alpha

    levels_sign_flipped = False

@functools.total_ordering
class Simplex(object):
    def __init__(self, index, index_map):
        self.index = index
        self.index_map = index_map

    def __eq__(self, other):
        return (isinstance(other, Simplex)
                and self.index_map is other.index_map
                and self.index == other.index)

    def __lt__(self, other):
        if not isinstance(other, Simplex):
            raise NotImplementedError
        if other.index_map is not self.index_map:
            raise NotImplementedError
        return self.index < other.index

    def __hash__(self):
        return hash((self.index, id(self.index_map)))

    def __repr__(self):
        return "index_map.Simplex(index={}, index_map={})".format(
            self.index, self.index_map
        )

    def vertices(self):
        return [Point(point, self.index_map) for point in self.index_map.simplices[self.index]]

    def point_coords(self):
        return [point.coord() for point in self.vertices()]

    def centroid(self):
        return np.mean(self.point_coords(), axis=0)

    def key(self):
        return tuple(sorted(self.index_map.simplices[self.index]))

    def frozen_key(self):
        return frozenset(self.index_map.simplices[self.index])

    def boundary_keys(self):
        if self.dim() == 0:
            return []
        s = tuple(sorted(self.index_map.simplices[self.index]))
        return [s[:i] + s[i+1:] for i in range(len(s))]

    def dim(self):
        return len(self.index_map.simplices[self.index]) - 1

    def boundary_keys_orientation(self):
        return [(key, (-1)**i) for (i, key) in enumerate(self.boundary_keys())]

    def time(self):
        return self.index_map.levels[self.index]


@functools.total_ordering
class Point(object):
    def __init__(self, index, index_map):
        self.index = index
        self.index_map = index_map

    def __eq__(self, other):
        return (isinstance(other, Point)
                and self.index_map is other.index_map
                and self.index == other.index)

    def __lt__(self, other):
        if not isinstance(other, Point):
            raise NotImplementedError
        if other.index_map is not self.index_map:
            raise NotImplementedError
        return self.index < other.index

    def __hash__(self):
        return hash((self.index, id(self.index_map)))

    def __repr__(self):
        return "index_map.Point(index={}, index_map={})".format(
            self.index, self.index_map
        )

    def coord(self):
        return self.index_map.points[self.index]
