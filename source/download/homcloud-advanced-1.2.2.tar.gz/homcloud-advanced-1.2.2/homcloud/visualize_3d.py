import itertools
from tempfile import TemporaryDirectory
import subprocess
import os
import math
from collections import defaultdict

import numpy as np

import homcloud.utils as utils

# TODO: this class requires unit tests
class ParaViewDrawer(object):
    def __init__(self, n_colors, points, column_names):
        self.n_colors = n_colors
        self.color_scalars = np.linspace(0, 1.0, n_colors + 3)
        self.points = [self.reformat_point(p) for p in points]
        self.lines = []
        self.colors = []
        self.columns = {name: list() for name in column_names}

    def various_colors(self):
        return self.color_scalars[:-3]

    @staticmethod
    def reformat_point(point):
        if len(point) == 3:
            return point
        if len(point) == 2:
            return (point[0], point[1], 0)

    def birth_color(self):
        return self.color_scalars[-2]

    def death_color(self):
        return self.color_scalars[-1]

    def draw_simplex(self, simplex, color, **threshold_values):
        for edge in itertools.combinations(simplex, 2):
            self.draw_line(edge[0], edge[1], color, **threshold_values)

    def draw_line(self, p, q, color, **threshold_values):
        self.lines.append((p, q))
        self.colors.append(color)
        for key, value in threshold_values.items():
            self.columns[key].append(value)

    def invoke(self):
        with TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "tmp.vtk")
            self.output(path)
            utils.invoke_paraview(path, nohup=False)

    def output(self, path):
        with open(path, "w") as f:
            self.output_header(f)
            self.output_polygon_data(f)
            self.output_line_colors(f)
            self.output_lookup_table(f)
            self.output_columns(f)

    @staticmethod
    def output_header(f):
        f.write("# vtk DataFile Version 2.0\n")
        f.write("birth death areas\n")
        f.write("ASCII\n")

    def output_polygon_data(self, f):
        f.write("DATASET POLYDATA\n")
        f.write("POINTS {} double\n".format(self.num_points()))
        for point in self.points:
            f.write("{} {} {}\n".format(point[0], point[1], point[2]))
        f.write("\n")

        f.write("LINES {} {}\n".format(self.num_lines(), self.num_lines()*3))
        for line in self.lines:
            f.write("2 {} {}\n".format(line[0], line[1]))
        f.write("\n")

    def output_line_colors(self, f):
        f.write("CELL_DATA {}\n".format(self.num_lines()))
        f.write("SCALARS colors float 1\n")
        f.write("LOOKUP_TABLE color_table\n")
        for n in self.colors:
            f.write("{}\n".format(n))

    def output_lookup_table(self, f):
        f.write("LOOKUP_TABLE color_table {}\n".format(self.n_colors + 3))
        for x in np.linspace(0.0, 1.0, self.n_colors+1):
            self.output_various_colors(f, x)
        self.output_birthdeath_colors(f)

    def output_columns(self, f):
        for (key, values) in self.columns.items():
            f.write("SCALARS {} float 1\n".format(key))
            f.write("LOOKUP_TABLE default\n")
            for value in values:
                f.write("{}\n".format(value))

    def num_points(self):
        return len(self.points)

    def num_lines(self):
        return len(self.lines)

    def output_various_colors(self, f, relative_value):
        f.write("{} {} {} 1.0\n".format(*self.color_spec(relative_value)))

    @staticmethod
    def output_birthdeath_colors(f):
        f.write("0.8 0.8 0.8 1.0\n")
        f.write("1.0 1.0 1.0 1.0\n")

    @staticmethod
    def color_spec(x):
        y, k = math.modf(x*6)
        if k == 0 or k == 6:
            return (1, y, 0)
        if k == 1:
            return (1-y, 1, 0)
        if k == 2:
            return (0, 1, y)
        if k == 3:
            return (0, 1-y, 1)
        if k == 4:
            return (y, 0, 1)
        if k == 5:
            return (1, 0, 1-y)
        return (0.5, 0.5, 0.5)

def boundary_of_connected_simplices(simplices):
    def boundaries(key):
        if len(key) == 1:
            return []
        return [key.difference([el]) for el in key]

    count = defaultdict(int)
    for simplex in simplices:
        for boundary in boundaries(simplex):
            count[boundary] += 1

    return [simplex for simplex, num in count.items() if num == 1]
