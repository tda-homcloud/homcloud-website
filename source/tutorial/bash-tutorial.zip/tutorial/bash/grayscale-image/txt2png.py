import numpy as np
import sys
import matplotlib.pyplot as plt
import imageio
from sklearn.preprocessing import minmax_scale
data = np.loadtxt(sys.argv[1])
data = (data - np.min(data)) / (np.max(data) - np.min(data)) * 255
imageio.imwrite(sys.argv[2], data.astype(np.uint8))
